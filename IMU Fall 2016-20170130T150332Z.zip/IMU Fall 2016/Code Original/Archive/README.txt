The SdRoot folder located here is the origonal SdRoot folder,
included for ease of access in case there are problems with the
new one.